package com.glory.runner

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("gloryrunner", MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var logText: TextView
    private lateinit var repoInput: EditText
    private lateinit var siteInput: EditText
    private lateinit var statusText: TextView
    private lateinit var web: WebView
    private var currentTab = "start"
    private val green = Color.rgb(57, 217, 138)
    private val bg = Color.rgb(16, 24, 32)
    private val panel = Color.rgb(27, 39, 50)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildShell()
        showTab("start")
        appendLog("GloryRunner ready.")
        appendLog("এটি app-এর নিজস্ব download manager; পূর্ণ Linux/Termux shell নয়।")
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(16, 18, 16, 0)
        }
        val header = TextView(this).apply {
            text = "GLORY RUNNER"
            textSize = 22f
            setTextColor(green)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 8, 4, 16)
        }
        root.addView(header)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }
        listOf("START", "LOG", "SETTINGS").forEach { label ->
            val key = label.lowercase()
            val b = Button(this).apply {
                text = label
                isAllCaps = false
                setTextColor(white)
                setBackgroundColor(panel)
                setOnClickListener { showTab(key) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(4,0,4,0) })
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showTab(tab: String) {
        currentTab = tab
        content.removeAllViews()
        when (tab) {
            "start" -> buildStart()
            "log" -> buildLog()
            else -> buildSettings()
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 16, 16, 16)
        setBackgroundColor(panel)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.BLACK)
            setBackgroundColor(green)
            setOnClickListener { action() }
        }

    private fun buildStart() {
        val box = card()
        box.addView(TextView(this).apply {
            text = "Welcome"
            textSize = 24f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "GitHub project ZIP ডাউনলোড ও extract করুন।"
            setTextColor(Color.LTGRAY)
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })
        statusText = TextView(this).apply {
            text = "Ready"
            setTextColor(green)
            setPadding(0, 8, 0, 8)
        }
        box.addView(statusText)
        box.addView(makeButton("▶ START DOWNLOAD") { startDownload() })
        box.addView(TextView(this).apply {
            text = "ডাউনলোড করা সোর্স: Android/data/com.glory.runner/files/Projects"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, 12, 0, 12)
        })
        box.addView(makeButton("OPEN WEBSITE") { openWebsite() })
        val scroll = ScrollView(this)
        scroll.addView(box)
        content.addView(scroll)
    }

    private fun buildLog() {
        logText = TextView(this).apply {
            setTextColor(Color.rgb(174, 255, 204))
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(12, 12, 12, 12)
            setTextIsSelectable(true)
            text = logBuffer.toString()
            setBackgroundColor(Color.rgb(8, 13, 18))
        }
        val sc = ScrollView(this)
        sc.addView(logText)
        content.addView(sc)
    }

    private fun buildSettings() {
        val box = card()
        box.addView(TextView(this).apply {
            text = "Settings"
            textSize = 22f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        box.addView(label("GitHub Repository URL"))
        repoInput = EditText(this).apply {
            setSingleLine(true)
            hint = "https://github.com/owner/repository"
            setText(prefs.getString("repo", DEFAULT_REPO))
            setTextColor(white)
            setHintTextColor(Color.GRAY)
        }
        box.addView(repoInput)
        box.addView(label("Website URL (ঐচ্ছিক)"))
        siteInput = EditText(this).apply {
            setSingleLine(true)
            hint = "https://example.com"
            setText(prefs.getString("site", ""))
            setTextColor(white)
            setHintTextColor(Color.GRAY)
        }
        box.addView(siteInput)
        box.addView(makeButton("SAVE SETTINGS") {
            prefs.edit()
                .putString("repo", repoInput.text.toString().trim())
                .putString("site", siteInput.text.toString().trim())
                .apply()
            toast("Settings saved")
            appendLog("Settings saved.")
        })
        box.addView(TextView(this).apply {
            text = "নিরাপত্তা: অ্যাপ শুধু GitHub-এর ZIP নামাবে ও extract করবে। setup.sh বা Python script নিজে থেকে execute করবে না।"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, 16, 0, 0)
        })
        val scroll = ScrollView(this)
        scroll.addView(box)
        content.addView(scroll)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        setTextColor(Color.LTGRAY)
        setPadding(0, 14, 0, 4)
    }

    private fun startDownload() {
        val repo = prefs.getString("repo", DEFAULT_REPO)?.trim().orEmpty()
        val parsed = parseRepo(repo)
        if (parsed == null) {
            toast("সঠিক GitHub repository URL দিন Settings-এ")
            return
        }
        statusText.text = "Downloading..."
        appendLog("Starting GitHub ZIP download: $repo")
        worker.execute {
            try {
                val zipUrl = "https://api.github.com/repos/${parsed.first}/${parsed.second}/zipball/HEAD"
                val conn = (URL(zipUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000
                    readTimeout = 60000
                    setRequestProperty("User-Agent", "GloryRunner-Android")
                    instanceFollowRedirects = true
                }
                if (conn.responseCode !in 200..299) error("GitHub HTTP ${conn.responseCode}")
                val projects = File(filesDir, "Projects").apply { mkdirs() }
                val zipFile = File(cacheDir, "project.zip")
                conn.inputStream.use { input -> zipFile.outputStream().use { input.copyTo(it) } }
                conn.disconnect()
                appendLog("ZIP downloaded (${zipFile.length()} bytes). Extracting...")
                val dest = File(projects, "${parsed.second}-latest")
                if (dest.exists()) dest.deleteRecursively()
                dest.mkdirs()
                extractZipSafely(zipFile, dest)
                zipFile.delete()
                runOnUiThread {
                    statusText.text = "Download complete"
                    appendLog("Extract complete: ${dest.absolutePath}")
                    toast("GitHub project downloaded")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Download failed"
                    appendLog("ERROR: ${e.message}")
                    toast("Download failed: ${e.message}")
                }
            }
        }
    }

    private fun extractZipSafely(zip: File, destination: File) {
        val rootPath = destination.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                val clean = entry.name.substringAfter('/', "")
                if (clean.isNotEmpty()) {
                    val out = File(destination, clean).canonicalFile
                    if (!out.path.startsWith(rootPath)) error("Unsafe ZIP entry blocked")
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { output -> zis.copyTo(output) }
                    }
                }
                zis.closeEntry()
            }
        }
    }

    private fun parseRepo(value: String): Pair<String, String>? {
        val u = value.removeSuffix(".git").trimEnd('/')
        val regex = Regex("""^https://github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)$""")
        val m = regex.matchEntire(u) ?: return null
        return m.groupValues[1] to m.groupValues[2]
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openWebsite() {
        val address = prefs.getString("site", "")?.trim().orEmpty()
        if (!address.startsWith("https://")) {
            toast("Settings-এ https:// website URL দিন")
            return
        }
        content.removeAllViews()
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl(address)
        }
        content.addView(web)
        appendLog("Opening website: $address")
    }

    private fun appendLog(line: String) {
        val stamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        logBuffer.append("[$stamp] $line\n")
        if (::logText.isInitialized) runOnUiThread { logText.text = logBuffer.toString() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        worker.shutdownNow()
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val DEFAULT_REPO = "https://github.com/mdariyan47484-ship-it/Glory"
        private val logBuffer = StringBuilder()
    }
}
